<script setup>
import { ref, onMounted } from "vue";
import axios from "axios";
import { fetchSidos } from "@/api/getDistricts";
const { OPEN_API_KEY } = "import.meta.env";

const BASE_URL = `https://apis.data.go.kr/B551011/KorService1/`;
const BASE_QUERY = `serviceKey=${OPEN_API_KEY}&numOfRows=50&pageNo=1&MobileOS=ETC&MobileApp=AppTest&_type=json&listYN=Y&arrange=A`;

const sidos = ref([]);
const attractions = ref([]);
const selectedSido = ref(0);
const selectedGugun = ref(0);
const searchKeyword = ref("");
const positions = ref([]);
const map = ref(null);

// 카카오 맵 API 로드
onMounted(async () => {
  await loadKakaoMapScript();

  // Fetch sidos and set them
  const response = await fetchSidos();
  sidos.value = response.data.response.body.items.item;

  // Initialize the map
  map.value = new window.kakao.maps.Map(document.getElementById("map"), {
    center: new window.kakao.maps.LatLng(37.500613, 127.036431),
    level: 5,
  });
});

// 카카오 맵 API 스크립트 로드
const loadKakaoMapScript = () => {
  return new Promise((resolve, reject) => {
    if (typeof kakao !== "undefined") {
      resolve();
      return;
    }

    const script = document.createElement("script");
    script.src =
      "//dapi.kakao.com/v2/maps/sdk.js?appkey=fda62c95cab1974ae44983d00f51bf1c&libraries=services,clusterer,drawing";
    script.onload = () => {
      window.kakao.maps.load(() => {
        resolve();
      });
    };
    script.onerror = reject;
    document.head.appendChild(script);
  });
};

const selectAll = (checkbox) => {
  const checkboxes = document.querySelectorAll('input[name="tourism-type"]');
  checkboxes.forEach((cb) => {
    cb.checked = checkbox.checked;
  });
};

const search = async () => {
  const sidoCode = selectedSido.value || 0;
  const gugunCode = selectedGugun.value || 0;
  const keyword = searchKeyword.value;
  let url = `${BASE_URL}/searchKeyword1?${BASE_QUERY}&areaCode=${sidoCode}&sigunguCode=${gugunCode}&keyword=${encodeURIComponent(
    keyword
  )}`;

  const selectedRadios = document.querySelectorAll(
    'input[name="tourism-type"]:checked'
  );
  selectedRadios.forEach((radio) => {
    url += `&contentTypeId=${radio.value}`;
  });

  const response = await axios.get(url);
  attractions.value = response.data.response.body.items.item;
  updateMapMarkers(attractions.value);
};

const updateMapMarkers = (trips) => {
  positions.value = trips.map((trip) => ({
    title: trip.title,
    addr: `${trip.addr1} ${trip.addr2}`,
    img: trip.firstimage || "default.png",
    latlng: new window.kakao.maps.LatLng(trip.mapy, trip.mapx),
  }));

  displayMarker();
};

const displayMarker = () => {
  const imageSrc = "../assets/img/marker1.png";
  const imageSize = new window.kakao.maps.Size(24, 35);
  positions.value.forEach((position) => {
    const markerImage = new window.kakao.maps.MarkerImage(imageSrc, imageSize);
    const marker = new window.kakao.maps.Marker({
      map: map.value,
      position: position.latlng,
      title: position.title,
      image: markerImage,
      clickable: true,
    });

    window.kakao.maps.event.addListener(marker, "click", function () {
      displayMarkerInfo(position);
    });

    marker.setMap(map.value);
  });

  map.value.setCenter(positions.value[0].latlng);
};

const displayMarkerInfo = (position) => {
  // Implement the info display logic here
  console.log("Display marker info:", position);
};

// const moveCenter = (lat, lng) => {
//   map.value.setCenter(new window.kakao.maps.LatLng(lat, lng));
// };

const fetchGuguns = async (sidoCode) => {
  const response = await axios.get(
    `${BASE_URL}/areaCode1?${BASE_QUERY}&areaCode=${sidoCode}`
  );
  return response.data.response.body.items.item;
};
</script>

<template>
  <div>
    <div style="height: 100px"></div>
    <div class="row">
      <div id="temp"></div>
      <div class="mt-3 text-center fw-bolder" id="search-header">
        <h2 class="mb-3">여행지 검색</h2>
      </div>
      <form class="d-flex my-3" role="search">
        <select
          v-model="selectedSido"
          class="form-select me-2"
          @change="fetchGuguns(selectedSido)">
          <option value="0" selected>검색 할 지역 선택</option>
          <option v-for="sido in sidos" :key="sido.code" :value="sido.code">
            {{ sido.name }}
          </option>
        </select>
        <select v-model="selectedGugun" class="form-select me-2">
          <option value="0" selected>시군구 선택</option>
          <!-- Add gugun options dynamically based on selected sido -->
        </select>
        <input
          v-model="searchKeyword"
          id="search-keyword"
          class="form-control me-2"
          type="search"
          placeholder="검색어"
          aria-label="검색어" />
        <button
          @click.prevent="search"
          id="btn-search"
          class="btn btn-outline-success"
          type="button">
          검색
        </button>
      </form>

      <div class="text-center">
        <div class="form-check form-check-inline">
          <input
            class="form-check-input"
            type="checkbox"
            id="select-all"
            @change="selectAll($event.target)" />
          <label class="form-check-label" for="select-all">모두</label>
        </div>
        <div
          class="form-check form-check-inline"
          v-for="type in tourismTypes"
          :key="type.value">
          <input
            class="form-check-input"
            type="checkbox"
            :id="`tourism-type-${type.value}`"
            name="tourism-type"
            :value="type.value" />
          <label class="form-check-label" :for="`tourism-type-${type.value}`">{{
            type.label
          }}</label>
        </div>
      </div>

      <div id="marker-info"></div>
      <div id="map" class="mt-3" style="width: 100%; height: 500px"></div>
      <div class="row" style="margin-top: 50px">
        <table class="table table-striped">
          <thead>
            <tr>
              <th>대표이미지</th>
              <th>관광지명</th>
              <th>주소</th>
              <th>위도</th>
              <th>경도</th>
            </tr>
          </thead>
          <tbody>
            <tr
              v-for="attraction in attractions"
              :key="attraction.contentId"
              @click="redirectToDetail(attraction.contentId)">
              <td>
                <img
                  :src="attraction.firstimage || 'default.png'"
                  width="100px" />
              </td>
              <td>{{ attraction.title }}</td>
              <td>{{ attraction.addr1 }} {{ attraction.addr2 }}</td>
              <td>{{ attraction.mapy }}</td>
              <td>{{ attraction.mapx }}</td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>
  </div>
</template>

<style scoped>
.navbar-brand img {
  max-height: 40px; /* 로고 이미지의 최대 높이 */
}

.navbar-nav .nav-item {
  margin-right: 10px; /* 네비게이션 요소 간의 우측 여백 */
}

.navbar-nav .nav-link {
  transition: color 0.3s; /* 색상 변화에 대한 애니메이션 효과 */
}

.navbar-nav .nav-link:hover {
  color: #007bff; /* 호버 시 색상 변경 */
  font-weight: bolder;
}

.form-check-input {
  transition: all 0.3s ease; /* 모든 스타일 속성에 대해 0.3초의 트랜지션 효과 적용 */
}

.form-check-input[type="checkbox"]:checked {
  transform: scale(1.2); /* 선택된 체크박스 확대 */
}

#search-header {
  margin: 40px 0;
}

#temp {
  height: 60px;
}
</style>
