<script setup></script>

<template>
  <div>TripPlanView</div>
</template>

<style scoped></style>
