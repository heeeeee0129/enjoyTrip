<script setup></script>

<template>
  <router-view />
</template>

<style>
.card {
  background-color: #f8f9fa;
  border: none;
}

.card-title {
  color: #007bff;
}

.card-text {
  font-size: 1.1rem;
}
</style>
