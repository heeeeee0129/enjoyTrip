<script setup></script>

<template>
  <div>NoticeView</div>
</template>

<style scoped></style>
